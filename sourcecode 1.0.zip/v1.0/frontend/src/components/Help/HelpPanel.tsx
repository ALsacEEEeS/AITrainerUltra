import { useState } from 'react';
import { useLanguage } from '../../i18n/LanguageProvider';

const ZH_HELP = {
  gettingStarted: {
    title: '🚀 快速开始',
    sections: [
      { title: '选择模型', content: '在"训练管理"页面选择模型类型（LLM、GPT、BERT、Whisper、Stable Diffusion 等），输入 HuggingFace 模型 ID 或本地路径。' },
      { title: '配置参数', content: '设置学习率、批次大小、训练轮数等超参数。Apple Silicon 用户建议启用 fp16 混合精度训练。' },
      { title: '开始训练', content: '点击"开始训练"按钮，实时查看损失曲线和训练日志。训练过程中可随时停止。' },
    ],
  },
  workflow: {
    title: '⚡ 工作流编辑',
    sections: [
      { title: '创建节点', content: '从左侧面板拖拽节点到画布。支持 20+ 节点类型：模型加载、数据集、训练、评估、自定义代码等。' },
      { title: '连接节点', content: '点击输出端口（右侧圆点）拖拽到输入端口（左侧圆点）创建连接。单击连线可选中，右键或点击"删除连线"删除。' },
      { title: '运行工作流', content: '点击底部"运行工作流"执行整个流水线。运行中可点击"停止"终止执行。' },
    ],
  },
  multimodal: {
    title: '🖼️ 多模态模型',
    sections: [
      { title: '预制多模态', content: '支持 CLIP（图文匹配）、BLIP（视觉问答）、LLaVA（视觉对话）等主流多模态模型。' },
      { title: '合成多模态', content: '在"合成多模态模型"中自由组合视觉编码器（ViT/ResNet/DINOv2）+ 文本编码器（BERT/T5/Phi）+ 音频编码器（Whisper/HuBERT），选择融合方式（拼接/交叉注意力/加权求和/MLP门控）。' },
      { title: '训练多模态', content: '设置好架构后点击"开始训练"，系统自动融合所选编码器并训练投影层。' },
    ],
  },
  optimization: {
    title: '⚡ 模型优化',
    sections: [
      { title: 'WOQ 量化', content: 'Weight-Only Quantization — 仅量化权重不量化激活。支持 INT8、NF4、GPTQ、AWQ、GGUF、MLX 等多种方法，可减少 2-16 倍显存。' },
      { title: 'Flash Attention', content: '内存高效注意力机制。NVIDIA Turing+ 使用 xformers/Triton，Apple Silicon M3+ 使用 PyTorch SDPA。' },
      { title: 'Apple Silicon 优化', content: 'M4/M5 芯片专用优化：统一内存管理、ANE 加速、MLX 量化框架。自动检测芯片型号并选择最优预设。' },
      { title: 'NVIDIA 预设', content: 'RTX 20/30/40/50 系列及专业卡（A6000、H100）专用优化，自动启用 FP8（Blackwell/Hopper）。' },
    ],
  },
  recipes: {
    title: '📋 训练食谱',
    sections: [
      { title: '什么是食谱', content: '食谱是预配置的训练参数模板，涵盖 LLM 微调、LoRA、QLoRA、DPO、Flash Attention、视频生成等多种场景。' },
      { title: '使用食谱', content: '点击食谱查看详情，点击"Use This Recipe"自动加载配置到训练页面。每个食谱包含硬件建议和预估时间。' },
      { title: 'Apple Silicon 提示', content: '所有食谱均包含 Apple Silicon（M1-M5）优化建议，以 🍎 标记显示。MPS 后端自动启用。' },
    ],
  },
  video: {
    title: '🎬 视频生成',
    sections: [
      { title: 'Stable Video Diffusion', content: '图像转视频模型。输入静态图像生成短视频。需要 NVIDIA 24GB+ 或 M3 Max 36GB+。' },
      { title: 'I2VGen-XL', content: '文本/图像转视频。阿里达摩院模型，支持中文描述生成视频。需要大显存（32GB+）。' },
      { title: '帧插值', content: '视频帧率提升。支持 FILM 和 RIFE 模型，将 24fps 视频提升至 60/120fps，可生成慢动作。' },
    ],
  },
  models: {
    title: '🤖 支持的模型类型',
    sections: [
      { title: '语言模型', content: 'LLM（GPT/LLaMA/Mistral）、GPT-2、BERT、T5、Phi（微软小型LLM）、RNN、LSTM、MoE（混合专家）' },
      { title: '视觉模型', content: 'Stable Diffusion、Flux（文生图）、CNN（分类）、DETR（目标检测）、SAM（分割）、Vision Transformer' },
      { title: '多模态/音频', content: 'CLIP、BLIP、LLaVA（视觉-语言）、Whisper（语音识别）、Embedding（文本向量化）' },
      { title: '视频', content: 'Stable Video Diffusion（图像→视频）、I2VGen-XL（文生视频）、Frame Interpolation（插帧）' },
    ],
  },
  tips: {
    title: '💡 实用技巧',
    sections: [
      { title: '内存优化', content: '统一内存（M4/M5）可容纳更大模型。如果 OOM，尝试：降低 batch_size → 启用梯度检查点 → 使用 4-bit 量化 → 启用 KV 卸载。' },
      { title: '模型格式', content: '支持 SafeTensors、PyTorch、GGUF、ONNX、MLX 等格式。自动检测 .safetensors 文件。' },
      { title: '虚拟环境', content: '建议使用虚拟环境隔离依赖。运行 python start.py --setup 自动创建 venv 并安装依赖。' },
      { title: '一键打包', content: '运行 python package.py 打包整个项目为单个 .exe 文件。支持 --quick（跳过压缩）和 --no-exe（仅构建前端）。' },
    ],
  },
};

const EN_HELP = {
  gettingStarted: {
    title: '🚀 Getting Started',
    sections: [
      { title: 'Select Model', content: 'In "Training" page, choose a model type (LLM, GPT, BERT, Whisper, Stable Diffusion, etc.) and enter a HuggingFace model ID or local path.' },
      { title: 'Configure Parameters', content: 'Set learning rate, batch size, epochs, etc. Apple Silicon users should enable fp16 mixed precision training.' },
      { title: 'Start Training', content: 'Click "Start Training" to begin. Monitor loss curves and training logs in real-time. Stop anytime.' },
    ],
  },
  workflow: {
    title: '⚡ Workflow Editor',
    sections: [
      { title: 'Create Nodes', content: 'Drag nodes from the left panel onto the canvas. 20+ node types: model loading, datasets, training, evaluation, custom code, and more.' },
      { title: 'Connect Nodes', content: 'Click and drag from output ports (right dots) to input ports (left dots). Click a connection to select it, right-click or press "Delete Connection" to remove.' },
      { title: 'Run Workflow', content: 'Click "Run Workflow" at the bottom to execute the pipeline. Press "Stop" to abort during execution.' },
    ],
  },
  multimodal: {
    title: '🖼️ Multimodal Models',
    sections: [
      { title: 'Pre-built Models', content: 'CLIP (image-text matching), BLIP (visual QA), LLaVA (visual dialogue) and other mainstream multimodal models.' },
      { title: 'Composite Multimodal', content: 'In "Composite Multimodal Model", freely combine vision encoders (ViT/ResNet/DINOv2) + text encoders (BERT/T5/Phi) + audio encoders (Whisper/HuBERT). Choose fusion method (concat/cross-attention/weighted-sum/MLP-gate).' },
      { title: 'Training', content: 'After configuring the architecture, click "Start Training". The system automatically fuses selected encoders and trains the projection layer.' },
    ],
  },
  optimization: {
    title: '⚡ Model Optimization',
    sections: [
      { title: 'WOQ Quantization', content: 'Weight-Only Quantization — quantizes only weights, not activations. Supports INT8, NF4, GPTQ, AWQ, GGUF, MLX. Reduces VRAM by 2-16x.' },
      { title: 'Flash Attention', content: 'Memory-efficient attention. NVIDIA Turing+ uses xformers/Triton, Apple Silicon M3+ uses PyTorch SDPA.' },
      { title: 'Apple Silicon', content: 'M4/M5 chip-specific optimizations: unified memory management, ANE acceleration, MLX quantization. Auto-detects chip model.' },
      { title: 'NVIDIA Presets', content: 'RTX 20/30/40/50 series and professional (A6000, H100) optimizations. Auto-enables FP8 on Blackwell/Hopper.' },
    ],
  },
  recipes: {
    title: '📋 Training Recipes',
    sections: [
      { title: 'What are Recipes', content: 'Pre-configured training parameter templates covering LLM fine-tuning, LoRA, QLoRA, DPO, Flash Attention, video generation, and more.' },
      { title: 'Using Recipes', content: 'Click a recipe to view details, press "Use This Recipe" to auto-load config into the Training page. Each recipe includes hardware recommendations and estimated time.' },
      { title: 'Apple Silicon Tips', content: 'All recipes include Apple Silicon (M1-M5) optimization tips, marked with 🍎. MPS backend auto-enabled.' },
    ],
  },
  video: {
    title: '🎬 Video Generation',
    sections: [
      { title: 'Stable Video Diffusion', content: 'Image-to-video model. Generate short videos from static images. Requires NVIDIA 24GB+ or M3 Max 36GB+.' },
      { title: 'I2VGen-XL', content: 'Text/image-to-video. DAMO Academy model from Alibaba. Supports Chinese prompts. Needs large VRAM (32GB+).' },
      { title: 'Frame Interpolation', content: 'Video frame rate upscaling. Supports FILM and RIFE models. Boost 24fps to 60/120fps. Create slow-motion.' },
    ],
  },
  models: {
    title: '🤖 Supported Model Types',
    sections: [
      { title: 'Language Models', content: 'LLM (GPT/LLaMA/Mistral), GPT-2, BERT, T5, Phi (Microsoft small LLM), RNN, LSTM, MoE (Mixture of Experts)' },
      { title: 'Vision Models', content: 'Stable Diffusion, Flux (image generation), CNN (classification), DETR (detection), SAM (segmentation), Vision Transformer' },
      { title: 'Multimodal/Audio', content: 'CLIP, BLIP, LLaVA (vision-language), Whisper (speech recognition), Embedding (text vectorization)' },
      { title: 'Video', content: 'Stable Video Diffusion (image→video), I2VGen-XL (text→video), Frame Interpolation' },
    ],
  },
  tips: {
    title: '💡 Tips & Tricks',
    sections: [
      { title: 'Memory Optimization', content: 'Unified memory (M4/M5) can hold larger models. If OOM: reduce batch_size → enable gradient checkpointing → use 4-bit quantization → enable KV offload.' },
      { title: 'Model Formats', content: 'Supports SafeTensors, PyTorch, GGUF, ONNX, MLX. Auto-detects .safetensors files.' },
      { title: 'Virtual Environment', content: 'Use virtual environments to isolate dependencies. Run python start.py --setup to auto-create venv and install deps.' },
      { title: 'One-Click Package', content: 'Run python package.py to package the entire project into a single .exe. Supports --quick (skip compression) and --no-exe (build frontend only).' },
    ],
  },
};

const SECTIONS = ['gettingStarted', 'workflow', 'multimodal', 'optimization', 'recipes', 'video', 'models', 'tips'] as const;

const SECTION_ICONS: Record<string, string> = {
  gettingStarted: '🚀', workflow: '⚡', multimodal: '🖼️',
  optimization: '⚡', recipes: '📋', video: '🎬', models: '🤖', tips: '💡',
};

export function HelpPanel() {
  const { lang } = useLanguage();
  const helpData = lang === 'en' ? EN_HELP : ZH_HELP;
  const [activeSection, setActiveSection] = useState<string>('gettingStarted');

  const section = helpData[activeSection as keyof typeof helpData];
  if (!section) return null;

  return (
    <div className="flex h-full">
      {/* Sidebar */}
      <div className="w-56 bg-surface-900 border-r border-surface-700 flex flex-col shrink-0">
        <div className="p-3 border-b border-surface-700">
          <h3 className="text-sm font-medium text-gray-300">
            {lang === 'en' ? 'Help & Docs' : '帮助文档'}
          </h3>
          <p className="text-xs text-gray-500 mt-0.5">
            {lang === 'en' ? 'Learn how to use AITrainerUltra' : '学习如何使用 AITrainerUltra'}
          </p>
        </div>
        <div className="flex-1 overflow-y-auto p-2">
          {SECTIONS.map((s) => {
            const sec = helpData[s as keyof typeof helpData];
            return (
              <button
                key={s}
                onClick={() => setActiveSection(s)}
                className={`w-full text-left p-2 rounded-lg mb-1 transition-colors ${
                  activeSection === s
                    ? 'bg-primary-600/20 border border-primary-500/30 text-primary-300'
                    : 'hover:bg-surface-800 text-gray-400'
                }`}
              >
                <span className="text-sm">{SECTION_ICONS[s]} {sec?.title}</span>
              </button>
            );
          })}
        </div>
      </div>

      {/* Content */}
      <div className="flex-1 overflow-y-auto p-6">
        <div className="max-w-3xl mx-auto">
          <h2 className="text-xl font-medium text-white mb-6">{section.title}</h2>
          <div className="space-y-4">
            {section.sections.map((s: { title: string; content: string }, idx: number) => (
              <div key={idx} className="card">
                <h3 className="text-sm font-medium text-primary-300 mb-2">{s.title}</h3>
                <p className="text-sm text-gray-400 leading-relaxed">{s.content}</p>
              </div>
            ))}
          </div>

          {/* Footer */}
          <div className="mt-8 p-4 bg-surface-900 rounded-lg border border-surface-700">
            <p className="text-xs text-gray-500 text-center">
              {lang === 'en'
                ? '💡 Tip: Most pages have Chinese/English toggle in the sidebar. Press Ctrl+F to search.'
                : '💡 提示: 侧边栏底部可切换中英文。按 Ctrl+F 搜索当前页面。'}
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
