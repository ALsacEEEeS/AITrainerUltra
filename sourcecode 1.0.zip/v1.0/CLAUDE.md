# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

## Project Overview

AITrainerUltra is a full-stack multi-model AI training framework. It consists of a Python/FastAPI backend (`backend/`) and a React/TypeScript frontend (`frontend/`). Supports 19 model types across 7 compute platforms (CUDA, MPS, ROCm, TPU, NPU, XPU, CPU).

## Key Architecture

### Backend (`backend/`)

```
backend/
├── api/           # FastAPI routes (45+ endpoints), schemas, WebSocket, server config
├── core/          # Training engine, config, model registry, events, experiment tracking,
│                  #   HPO, pipeline templates, plugin system, scheduler, recipes
├── models/        # 19 model trainers + model_loader, model_manager, evaluator, serving
├── data/          # Dataset classes, processors, tokenizer utils, generator, real_data
└── utils/         # Device detection, optimizations, layers, checkpoint, logging, metrics
```

**Critical patterns:**
- **Lazy torch imports** — All `import torch` is optional. Modules that use torch wrap imports in `try/except ImportError:` so the server starts without torch. This is required for PyInstaller packaging.
- **Model registry** — Trainers register via `registry.register_trainer()` in `server.py` (not decorators). Uses lazy string-based module paths.
- **BaseTrainer** — All trainers extend `BaseTrainer` which auto-detects the best compute device via `device.py`.
- **Synthetic data fallback** — Every trainer first tries real datasets (HuggingFace), falls back to synthetic data if unavailable.

### Frontend (`frontend/`)

```
frontend/src/
├── components/     # 9 panels: NodeEditor, ChatInterface, Training, Multimodal,
│                   #   Experiments, ModelManager, ModelLoader, Optimization, Recipes
│   ├── Layout/     # Sidebar, TopBar (bilingual + device selector)
│   └── Device/     # DeviceSelector widget (compact + full modes)
├── i18n/           # Bilingual (zh/en) support with context provider
├── store/          # Zustand stores: training, model, workflow
└── api/            # REST client + WebSocket client
```

**Key frontend patterns:**
- `App.tsx` defines union type `Tab` for navigation; adding a new panel means adding to `Tab`, `App.tsx render`, `Sidebar`, `TopBar`, and `translations.ts`.
- `LanguageProvider` wraps the app with `t(key)` function for translations.
- `DeviceSelector` component is reusable across panels.

## Commands

### Backend

```bash
# Start server (development)
uvicorn backend.api.server:app --host 127.0.0.1 --port 8000 --reload

# Start server (production)
python -m uvicorn backend.api.server:app --host 0.0.0.0 --port 8000

# Install deps
pip install -r backend/requirements.txt
```

### Frontend

```bash
cd frontend
npm install
npm run dev      # Dev server on :3000
npm run build    # Production build to dist/
```

### Build .exe

```bash
# Prerequisites: frontend built, pyinstaller installed
python build/build_exe.py --skip-frontend
# Output: dist/AITrainerUltra.exe
```

## Adding a New Model Type

1. Create trainer class in `backend/models/` extending `BaseTrainer`
2. Implement `load_model()` and `train()` (use `self.device` for compute)
3. Register in `backend/api/server.py` via `registry.register_trainer(name, module_path, info)`
4. Add preset in `backend/core/config.py` → `MODEL_PRESETS`
5. Add frontend option in `frontend/src/components/NodeEditor/types.ts` model_type select
6. (Optional) Add pipeline template in `backend/core/pipeline.py`

## Key Conventions

- **Imports:** No top-level `import torch` or `import transformers` outside of model files; use lazy imports inside functions
- **Device:** Never hardcode `torch.device("cuda" if ...)`; use `self.device` from BaseTrainer or `get_torch_device()` from `device.py`
- **Error handling:** Wrap torch-dependent code in try/except so CPU-only/headless mode works
- **TypeScript:** Run `node node_modules/typescript/bin/tsc --noEmit` from `frontend/` to check

## Device Detection Priority

`backend/utils/device.py` → `detect_device()` checks in order:
1. CUDA (NVIDIA)
2. TPU (torch_xla)
3. NPU (torch_npu)
4. XPU (Intel)
5. MPS (Apple Silicon)
6. ROCm (AMD)
7. CPU (fallback)

## Common Pitfalls

- Always add new tab IDs to both `tabLabels` AND `tabDescriptions` in `TopBar.tsx`
- The `from __future__ import annotations` in Python files makes type hints strings, preventing import-time failures from undefined torch types
- PyInstaller builds require `collect_submodules` for FastAPI/Starlette/Uvicorn
- When torch is not available, `serving.py` methods use internal lazy imports; routes using `inference_server` must also use lazy imports

## Community & Project Files

Key project files for GitHub publishing:
- `LICENSE` — MIT License
- `CONTRIBUTING.md` — Contribution guidelines (including how to add new model types)
- `CODE_OF_CONDUCT.md` — Contributor Covenant v2.1
- `SECURITY.md` — Security policy and vulnerability reporting
- `CHANGELOG.md` — Release history (Keep a Changelog format)
- `.github/ISSUE_TEMPLATE/` — Bug report and feature request templates
- `.github/PULL_REQUEST_TEMPLATE.md` — PR checklist template
- `.github/workflows/ci.yml` — CI pipeline (ruff + pytest + tsc + build)
- `.env.example` — Documented environment variables
- `.editorconfig` — Editor consistency settings
