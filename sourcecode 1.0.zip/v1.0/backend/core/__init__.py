"""Core engine and utilities."""
